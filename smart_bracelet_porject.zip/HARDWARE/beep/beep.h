#ifndef __BEEP_H__
#define __BEEP_H__

#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"

#define BEEP  PFout(8)

void beep_init(void);
void alarm_ring(void);


#endif
