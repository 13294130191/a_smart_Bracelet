#include "exti.h"

//GPIO初始化的结构体
static GPIO_InitTypeDef  GPIO_InitStructure;

static EXTI_InitTypeDef  EXTI_InitStructure;

static NVIC_InitTypeDef  NVIC_InitStructure;

static OS_ERR err;

void exit_init(void)
{

        //使能端口A E F的硬件时钟，说白就是对端口A E F供电
    RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOF|
                            RCC_AHB1Periph_GPIOE|
                            RCC_AHB1Periph_GPIOA, ENABLE);
    
    
    //配置端口F的9 10号引脚为输出模式
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_10;           //第9根引脚
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;       //输出模式
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽输出，增加驱动能力就是增加输出电流，还有吸收灌电流
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  //工作速度100MHz，工作速度越高，功耗就会越高
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;    //不需要上下拉电阻
    GPIO_Init(GPIOF, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14;  
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    
    //配置PA0为输入模式
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    //1 使能SYSCFG时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    
    //配置中断优先级的分组选择组2
    //2 支持4个抢占优先级、4个响应优先级
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    //3 将PA0引脚连接到外部中断线0
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);
    
    // 将PE2 PE3 PE4连接连接到对应的外部中断线2、3、4
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource2);
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource3);
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource4);
            
    
    
    //4 配置外部中断的触发方式：边沿触发、电平触发，就立即跳转到中断服务函数进行处理
    EXTI_InitStructure.EXTI_Line = EXTI_Line0|EXTI_Line2|EXTI_Line3|EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    
    //5 配置外部中断0优先级
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;            //中断号
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x03;       //子（响应）优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             //使能该中断
    NVIC_Init(&NVIC_InitStructure);
            
    //配置外部中断2优先级
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;            //中断号
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x03;       //子（响应）优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             //使能该中断
    NVIC_Init(&NVIC_InitStructure);         
            
    //配置外部中断3优先级
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;            //中断号
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x03;       //子（响应）优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             //使能该中断
    NVIC_Init(&NVIC_InitStructure);

    //配置外部中断4优先级
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;            //中断号
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;       //子（响应）优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             //使能该中断
    NVIC_Init(&NVIC_InitStructure);
    
    
    PFout(10)=1;
    PFout(9)=1;
    
    PEout(13)=1;
    PEout(14)=1;
}

/**
  * @brief  This function handles External line 0 interrupt request.
  * @param  None
  * @retval None
  */
void EXTI0_IRQHandler(void)
{
		//进入中断
	OSIntEnter();
	//检查是否有外部中断0的请求
	if(EXTI_GetITStatus(EXTI_Line0) == SET)
	{
		//0x01：操作bit0
		//OS_OPT_POST_FLAG_SET:置1
		OSFlagPost(&g_os_flag,0x01,OS_OPT_POST_FLAG_SET,&err);
		
		/*清空外部中断0的标志位， 告诉CPU，当前已经完成中断请求，可以进行新的中断处理
		  思考：如果不清空标志位，会出现什么现象？
		*/
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
	//退出中断
	OSIntExit();
}

void EXTI2_IRQHandler(void)
{
	//进入中断
	OSIntEnter();
	//检查是否有外部中断2的请求
	if(EXTI_GetITStatus(EXTI_Line2) == SET)
	{
		//0x02：操作bit1
		//OS_OPT_POST_FLAG_SET:置1
		OSFlagPost(&g_os_flag,0x02,OS_OPT_POST_FLAG_SET,&err);
		
		/*清空外部中断2的标志位， 告诉CPU，当前已经完成中断请求，可以进行新的中断处理
		  思考：如果不清空标志位，会出现什么现象？
		*/
		EXTI_ClearITPendingBit(EXTI_Line2);
	}
	//退出中断
	OSIntExit();
}


void EXTI3_IRQHandler(void)
{
	//进入中断
	OSIntEnter();
	//检查是否有外部中断3的请求
	if(EXTI_GetITStatus(EXTI_Line3) == SET)
	{
		//0x04：操作bit30
		//OS_OPT_POST_FLAG_SET:置1
		OSFlagPost(&g_os_flag,0x04,OS_OPT_POST_FLAG_SET,&err);
		
		/*清空外部中断3的标志位， 告诉CPU，当前已经完成中断请求，可以进行新的中断处理
		  思考：如果不清空标志位，会出现什么现象？
		*/
		EXTI_ClearITPendingBit(EXTI_Line3);
	}
	//退出中断
	OSIntExit();
}

void EXTI4_IRQHandler(void)
{
	//进入中断
	OSIntEnter();
	//检查是否有外部中断4的请求
	if(EXTI_GetITStatus(EXTI_Line4) == SET)
	{
		//0x08：操作bit4
		//OS_OPT_POST_FLAG_SET:置1
		OSFlagPost(&g_os_flag,0x08,OS_OPT_POST_FLAG_SET,&err);
		
		/*清空外部中断4的标志位， 告诉CPU，当前已经完成中断请求，可以进行新的中断处理
		  思考：如果不清空标志位，会出现什么现象？
		*/
		EXTI_ClearITPendingBit(EXTI_Line4);
	}
	//退出中断
	OSIntExit();
}
