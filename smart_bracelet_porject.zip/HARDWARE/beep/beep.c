#include "beep.h"

//GPIO初始化的结构体
static GPIO_InitTypeDef  GPIO_InitStructure;


void beep_init(void)
{
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
        /* 配置PF8为输出模式 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;                    //第8根引脚
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;               //设置为输出模式
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;              //推挽模式，增加驱动电流
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;          //设置IO的速度为100MHz，频率越高性能越好，频率越低，功耗越低
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;            //不需要上拉电阻
    GPIO_Init(GPIOF, &GPIO_InitStructure);

}
void alarm_ring(void)
{
	uint32_t i;
	for(i=0;i<8;i++)
	{
		BEEP=1;
		PFout(9) =0;
		PFout(10)=0;
		PEout(13)=0;
		PEout(14)=0;
		delay_ms(100);
		
		BEEP=0;
		PFout(9) =1;
		PFout(10)=1;
		PEout(13)=1;
		PEout(14)=1;		
		delay_ms(100);
		
		BEEP=1;
		PFout(9) =0;
		PFout(10)=0;
		PEout(13)=0;
		PEout(14)=0;		
		delay_ms(100);
		
		BEEP=0;
		PFout(9) =1;
		PFout(10)=1;
		PEout(13)=1;
		PEout(14)=1;		
		delay_ms(300);
		
	}
	BEEP=0;
}
