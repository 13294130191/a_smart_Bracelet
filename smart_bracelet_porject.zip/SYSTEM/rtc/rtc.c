#include "rtc.h"



EXTI_InitTypeDef  EXTI_InitStructure;

NVIC_InitTypeDef  NVIC_InitStructure;

RTC_DateTypeDef  RTC_DateStructure;     //日期
RTC_TimeTypeDef  RTC_TimeStructure;     //时间
RTC_InitTypeDef  RTC_InitStructure;     //初始化
RTC_AlarmTypeDef RTC_AlarmStructure;    //闹钟的结构体

static OS_ERR err;

void rtc_init(void)
{

	//使能RTC的时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	
	/* 允许访问RTC*/
	PWR_BackupAccessCmd(ENABLE);
	
	
	
	//使能外部的LSE振荡时钟
	RCC_LSEConfig(RCC_LSE_ON);
	
	//检查LSE是否就绪：1）是否起振 2）有没有焊接好
	while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);
	
	//选择时钟源，LSE/LSI，最终选择LSE（32768Hz）
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	
	/* Enable the RTC Clock，使能RTC硬件 */
	RCC_RTCCLKCmd(ENABLE);
	
	/* Wait for RTC APB registers synchronisation ，等待所有RTC相关的寄存器就绪*/
	RTC_WaitForSynchro();
	
	//要进行分频，最终RTC的时钟频率为=32768Hz/(127+1)/(255+1)=1Hz
	RTC_InitStructure.RTC_AsynchPrediv = 127;				//第一次分频
	RTC_InitStructure.RTC_SynchPrediv = 255;				//第二次分频
	RTC_InitStructure.RTC_HourFormat = RTC_HourFormat_24;	//24小时格式
	RTC_Init(&RTC_InitStructure);
	
	
	//设置年月日星期几
	//2019/4/2 
	RTC_DateStructure.RTC_Year = 0x19;				//2019
	RTC_DateStructure.RTC_Month = RTC_Month_April;	//4
	RTC_DateStructure.RTC_Date = 0x02;				//2
	RTC_DateStructure.RTC_WeekDay = RTC_Weekday_Tuesday;//星期二
	RTC_SetDate(RTC_Format_BCD, &RTC_DateStructure);
	
	
	//设置时分秒
	//04:16:16 PM
	RTC_TimeStructure.RTC_H12     = RTC_H12_PM;		
	RTC_TimeStructure.RTC_Hours   = 0x04;
	RTC_TimeStructure.RTC_Minutes = 0x16;
	RTC_TimeStructure.RTC_Seconds = 0x16; 
	
	RTC_SetTime(RTC_Format_BCD, &RTC_TimeStructure); 	
	
	
	//配置RTC的日历时钟中断，1秒触发一次中断
	//关闭唤醒功能
	RTC_WakeUpCmd(DISABLE);
	
	//为唤醒功能选择RTC配置好的时钟源
	RTC_WakeUpClockConfig(RTC_WakeUpClock_CK_SPRE_16bits);
	
	//设置唤醒计数值为自动重载，写入值默认是0
	RTC_SetWakeUpCounter(0);
	
	//清除RTC唤醒中断标志
	RTC_ClearITPendingBit(RTC_IT_WUT);
	
	//使能RTC唤醒中断
	RTC_ITConfig(RTC_IT_WUT, ENABLE);

	//使能唤醒功能
	RTC_WakeUpCmd(ENABLE);	
	
	
	//配置外部中断线22的中断
	EXTI_ClearITPendingBit(EXTI_Line22);
	EXTI_InitStructure.EXTI_Line = EXTI_Line22;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	
	//配置优先级
	NVIC_InitStructure.NVIC_IRQChannel = RTC_WKUP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);		

   
}

void rtc_set(void)
{
//读取RTC备份寄存器的值是否为0x6666，如果不是0x8888，则不需要进行重置RTC的日期和时间
	if((RTC_ReadBackupRegister(RTC_BKP_DR0) != 0x8888))
	{
		//重置RTC的日期和时间
		rtc_init();
		
		//并且对备份寄存器建立标志值为0x8888
		RTC_WriteBackupRegister(RTC_BKP_DR0, 0x8888);
	
	}
	else
	{
		//使能RTC的时钟
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
		
		/* 允许访问RTC*/
		PWR_BackupAccessCmd(ENABLE);
		
		
		
		//使能外部的LSE振荡时钟
		RCC_LSEConfig(RCC_LSE_ON);
		
		//检查LSE是否就绪：1）是否起振 2）有没有焊接好
		while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);
		
		//选择时钟源，LSE/LSI，最终选择LSE（32768Hz）
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		
		/* Enable the RTC Clock，使能RTC硬件 */
		RCC_RTCCLKCmd(ENABLE);
		
		/* Wait for RTC APB registers synchronisation ，等待所有RTC相关的寄存器就绪*/
		RTC_WaitForSynchro();	
		
		
		//清除RTC唤醒中断标志
		RTC_ClearITPendingBit(RTC_IT_WUT);
		
		//使能RTC唤醒中断
		RTC_ITConfig(RTC_IT_WUT, ENABLE);


		
		//配置外部中断线22的中断
		EXTI_ClearITPendingBit(EXTI_Line22);
		EXTI_InitStructure.EXTI_Line = EXTI_Line22;
		EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
		EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
		EXTI_InitStructure.EXTI_LineCmd = ENABLE;
		EXTI_Init(&EXTI_InitStructure);
		
		
		//配置优先级
		NVIC_InitStructure.NVIC_IRQChannel = RTC_WKUP_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);			
	
	}
}
void rtc_alarma_set(uint8_t hours,uint8_t minutes,uint8_t seconds)
{
    
    //关闭闹钟，才能配置
    RTC_AlarmCmd(RTC_Alarm_A, DISABLE);
    
    
    /* 配置闹钟时间为04:16:30 PM*/
	if(hours<12)
		RTC_AlarmStructure.RTC_AlarmTime.RTC_H12     = RTC_H12_AM;
	else
		RTC_AlarmStructure.RTC_AlarmTime.RTC_H12     = RTC_H12_PM;
	
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Hours   = hours;
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Minutes = minutes;
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Seconds = seconds;

    //闹钟每天都会生效
    #if 1
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x31;
        //RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_Date;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_DateWeekDay;
    #endif

    //闹钟指定某一天生效
    #if 0
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x03;
        RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_Date;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_None;  
    #endif  

    #if 0
    //闹钟指定某一星期生效
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x02;
        RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_WeekDay;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_None;      
    #endif  

    /* 配置闹钟A*/
    RTC_SetAlarm(RTC_Format_BCD, RTC_Alarm_A, &RTC_AlarmStructure);
    
    /* 使能闹钟A的中断 */
    RTC_ITConfig(RTC_IT_ALRA, ENABLE);
    
    /* 使能闹钟A */
    RTC_AlarmCmd(RTC_Alarm_A, ENABLE);


    RTC_ClearFlag(RTC_FLAG_ALRAF);
    
    //配置外部中断线17的中断
    EXTI_ClearITPendingBit(EXTI_Line17);
    EXTI_InitStructure.EXTI_Line = EXTI_Line17;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    
    //配置优先级
    NVIC_InitStructure.NVIC_IRQChannel = RTC_Alarm_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);     

}

void rtc_alarmb_set(uint8_t hours,uint8_t minutes,uint8_t seconds)
{
    
    //关闭闹钟，才能配置
    RTC_AlarmCmd(RTC_Alarm_B, DISABLE);
    
    
    /* 配置闹钟时间为04:16:30 PM*/
	if(hours<12)
		RTC_AlarmStructure.RTC_AlarmTime.RTC_H12     = RTC_H12_AM;
	else
		RTC_AlarmStructure.RTC_AlarmTime.RTC_H12     = RTC_H12_PM;
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Hours   = hours;
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Minutes = minutes;
    RTC_AlarmStructure.RTC_AlarmTime.RTC_Seconds = seconds;

    //闹钟每天都会生效
    #if 1
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x31;
        //RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_Date;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_DateWeekDay;
    #endif

    //闹钟指定某一天生效
    #if 0
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x03;
        RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_Date;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_None;  
    #endif  

    #if 0
    //闹钟指定某一星期生效
        RTC_AlarmStructure.RTC_AlarmDateWeekDay = 0x02;
        RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_WeekDay;
        RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_None;      
    #endif  

    /* 配置闹钟B*/
    RTC_SetAlarm(RTC_Format_BCD, RTC_Alarm_B, &RTC_AlarmStructure);
    
    /* 使能闹钟B的中断 */
    RTC_ITConfig(RTC_IT_ALRB, ENABLE);
    
    /* 使能闹钟B */
    RTC_AlarmCmd(RTC_Alarm_B, ENABLE);


    RTC_ClearFlag(RTC_FLAG_ALRAF);
    
    //配置外部中断线17的中断
    EXTI_ClearITPendingBit(EXTI_Line17);
    EXTI_InitStructure.EXTI_Line = EXTI_Line17;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    
    //配置优先级
    NVIC_InitStructure.NVIC_IRQChannel = RTC_Alarm_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);     

}


void set_date(uint8_t year,uint8_t month,uint8_t date,uint8_t weekdaye)
{

    //设置年月日星期几
     
    RTC_DateStructure.RTC_Year = year;       //2019
    RTC_DateStructure.RTC_Month = month;     //4
    RTC_DateStructure.RTC_Date = date;       //2
    RTC_DateStructure.RTC_WeekDay = weekdaye;//星期二
    RTC_SetDate(RTC_Format_BCD, &RTC_DateStructure);    

}

void set_time(uint8_t hours,uint8_t minutes,uint8_t seconds)
{

    //设置时分秒
    //04:16:16 PM
	if(hours<12)
		RTC_TimeStructure.RTC_H12     = RTC_H12_AM;
	else
		RTC_TimeStructure.RTC_H12     = RTC_H12_PM; 
	
    RTC_TimeStructure.RTC_Hours   = hours;
    RTC_TimeStructure.RTC_Minutes = minutes;
    RTC_TimeStructure.RTC_Seconds = seconds; 
    RTC_SetTime(RTC_Format_BCD, &RTC_TimeStructure);
}





void RTC_Alarm_IRQHandler(void)
{
    //进入中断
    OSIntEnter();
    //检查是否有RTC闹钟A中断
    if(RTC_GetITStatus(RTC_IT_ALRA)==SET)
    {
        
        //0x10：操作bit4
        //OS_OPT_POST_FLAG_SET:置1
        OSFlagPost(&g_os_flag,0x10,OS_OPT_POST_FLAG_SET,&err);
        
        //清空标志位
        RTC_ClearITPendingBit(RTC_IT_ALRA);
        
        EXTI_ClearITPendingBit(EXTI_Line17);
    }

    if(RTC_GetITStatus(RTC_IT_ALRB)==SET)
    {
        
        //0x20：操作bit5
        //OS_OPT_POST_FLAG_SET:置1
        OSFlagPost(&g_os_flag,0x20,OS_OPT_POST_FLAG_SET,&err);
        
        //清空标志位
        RTC_ClearITPendingBit(RTC_IT_ALRB);
        
        EXTI_ClearITPendingBit(EXTI_Line17);
    }
    //退出中断
    OSIntExit();
}


void RTC_WKUP_IRQHandler(void)
{
    //进入中断
    OSIntEnter();
    //检查是否有RTC唤醒中断
    if(RTC_GetITStatus(RTC_IT_WUT)==SET)
    {
        
        //0x40：操作bit6
        //OS_OPT_POST_FLAG_SET:置1

         OSFlagPost(&g_os_flag,0x40,OS_OPT_POST_FLAG_SET,&err);
        //清空标志位
        RTC_ClearITPendingBit(RTC_IT_WUT);
        
        EXTI_ClearITPendingBit(EXTI_Line22);
    }
    //退出中断
    OSIntExit();
       
}

