#include "bluetooth.h"

void ble_set_config(void)
{
    
    
    //配置蓝牙模块的名字
    usart3_send_str("AT+NAMEStudent.Yan\r\n");
    
    delay_ms(200);
    
    
    //获取模块的本地地址
    usart3_send_str("AT+LADDR\r\n");
    
    delay_ms(200);  

}
