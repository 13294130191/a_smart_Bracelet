#ifndef __MAIN_H__
#define __MAIN_H__

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "includes.h"
#include "stm32f4xx.h"
#include "string.h"
#include "stdio.h"
#include "i2c.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "dmpKey.h"
#include "dmpmap.h"
#include "oled.h"
#include "bmp.h"
#include "exti.h"
#include "beep.h"
#include "rtc.h"
#include "bluetooth.h"
#include "max30102.h" 
#include "algorithm.h"

#define MAX_BRIGHTNESS 255

extern EXTI_InitTypeDef  EXTI_InitStructure;
extern RTC_DateTypeDef  RTC_DateStructure;     //日期
extern RTC_TimeTypeDef  RTC_TimeStructure;     //时间
//===============max30102===========================
uint32_t aun_ir_buffer[500];    //IR LED sensor data
int32_t n_ir_buffer_length;     //data length
uint32_t aun_red_buffer[500];   //Red LED sensor data
int32_t n_sp02;                 //SPO2 value
int8_t ch_spo2_valid;           //indicator to show if the SP02 calculation is valid
int32_t n_heart_rate;           //heart rate value
int8_t  ch_hr_valid;            //indicator to show if the heart rate calculation is valid
uint8_t uch_dummy;
//====================================================
uint32_t sleep_flag=0;          //睡眠标记
unsigned long step_num=0;       //步数
uint8_t g_h=12,g_m=30,g_s=30;   //时分秒
uint32_t g_n=2019,g_y=04,g_d=18;//年月日
uint8_t g_alarm_a_b=1;          //闹钟A=1，闹钟B=2
/*********************************任务******************************************/
//任务1控制块
OS_TCB Task1_TCB;
void task1(void *parg);
CPU_STK task1_stk[1048];        //任务1的任务堆栈，大小为1048字，也就是1048*4字节

//任务2控制块
OS_TCB Task2_TCB;
void task2(void *parg);
CPU_STK task2_stk[256];         //任务2的任务堆栈，大小为256字，也就是256*4字节

//任务3控制块
OS_TCB Task3_TCB;
void task3(void *parg);
CPU_STK task3_stk[256];         //任务3的任务堆栈，大小为256字，也就是256*4字节

//任务4控制块
OS_TCB Task4_TCB;
void task4(void *parg);
CPU_STK task4_stk[256];         //任务4的任务堆栈，大小为256字，也就是256*4字节

//任务5控制块
OS_TCB Task5_TCB;
void task5(void *parg);
CPU_STK task5_stk[256];         //任务5的任务堆栈，大小为256字，也就是256*4字节

//任务6控制块
OS_TCB Task6_TCB;
void task6(void *parg);
CPU_STK task6_stk[512];         //任务6的任务堆栈，大小为512字，也就是512*4字节

//任务7控制块
OS_TCB Task7_TCB;
void task7(void *parg);
CPU_STK task7_stk[512];         //任务7的任务堆栈，大小为512字，也就是512*4字节

//任务8控制块
OS_TCB Task8_TCB;
void task8(void *parg);
CPU_STK task8_stk[256];         //任务8的任务堆栈，大小为256字，也就是256*4字节

//任务9控制块
OS_TCB Task9_TCB;
void task9(void *parg);
CPU_STK task9_stk[128];         //任务9的任务堆栈，大小为128字，也就是128*4字节

//任务10控制块
OS_TCB Task10_TCB;
void task10(void *parg);
CPU_STK task10_stk[128];         //任务9的任务堆栈，大小为128字，也就是128*4字节
/*********************************************************************************/

OS_MUTEX g_mutex;               //定义一个互斥量（互斥锁），用于资源的保护

OS_FLAG_GRP  g_os_flag;         //定义一个事件标志组

OS_Q g_queue;                   //定义一个消息队列

OS_TMR	g_tmr1;					//定义一个软件定时器
//=====================================================
//====================界面结构体=======================
struct num_two_xmb
{
	int group;

}t_xmb[3];

struct XMB
{
	struct num_two_xmb t_xmb[3];
	int group;
	
}o_xmb;
//====================================================

void Uart0NimingReport(u8 fun,u8*data,u8 len);
void MPU6050SendData(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz);
void Uart0ReportImu(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz,short roll,short pitch,short yaw);
void dis_DrawCurve(u32* data,u8 x);
void struct_init (void);
void  TmrCallback (OS_TMR *p_tmr, void *p_arg);

#endif
