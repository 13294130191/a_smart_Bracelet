#ifndef __RTC_H__
#define __RTC_H__

#include "stm32f4xx.h"
#include "sys.h"
#include "includes.h"					//ucos ʹ��	  
#include "delay.h"

extern OS_FLAG_GRP  g_os_flag;

void rtc_init(void);
void rtc_alarma_set(uint8_t hours,uint8_t minutes,uint8_t seconds);
void set_date(uint8_t year,uint8_t month,uint8_t date,uint8_t weekdaye);
void set_time(uint8_t hours,uint8_t minutes,uint8_t seconds);
void rtc_alarmb_set(uint8_t hours,uint8_t minutes,uint8_t seconds);

void rtc_set(void);


#endif
