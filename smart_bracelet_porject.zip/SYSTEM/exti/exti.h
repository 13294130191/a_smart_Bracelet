#ifndef __EXTI_H__
#define __EXTI_H__

#include "stm32f4xx.h"
#include "sys.h"
#include "includes.h"					//ucos ʹ��	  
#include "delay.h"

extern OS_FLAG_GRP  g_os_flag;

void exit_init(void);


#endif
