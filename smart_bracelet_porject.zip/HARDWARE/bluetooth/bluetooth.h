#ifndef __BLUETOOTH_H__
#define __BLUETOOTH_H__

#include "stm32f4xx.h"
//#include "sys.h"
#include "delay.h"
#include "usart.h"  

void ble_set_config(void);


#endif
